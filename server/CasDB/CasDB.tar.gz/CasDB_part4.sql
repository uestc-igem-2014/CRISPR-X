-- MySQL dump 10.11
--
-- Host: localhost    Database: CasDB
-- ------------------------------------------------------
-- Server version	5.0.88

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Table_result`
--

DROP TABLE IF EXISTS `Table_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Table_result` (
  `result_ID` int(11) NOT NULL auto_increment,
  `sgrna_ID` int(11) NOT NULL,
  `result_kind` int(11) NOT NULL,
  `result_ntlength` int(11) NOT NULL,
  `result_Sspe` decimal(6,2) NOT NULL,
  `result_Seff` decimal(6,2) NOT NULL,
  `result_offtarget` varchar(10000) NOT NULL,
  `result_count` int(11) NOT NULL,
  `result_gc` decimal(5,4) NOT NULL,
  PRIMARY KEY  (`result_ID`),
  KEY `sgrna_ID` (`sgrna_ID`),
  KEY `result_kind` (`result_kind`),
  KEY `result_ntlength` (`result_ntlength`)
) ENGINE=MyISAM AUTO_INCREMENT=6509 DEFAULT CHARSET=utf8;
